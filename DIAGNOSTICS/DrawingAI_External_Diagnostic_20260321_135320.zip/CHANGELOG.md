# Changelog

כל השינויים המשמעותיים בפרויקט מתועדים כאן.

## [3.1.0] - 2026-02-21

### תיקונים
- **PL Detection** — regex לא תפס `PL_TL-4341` (underscore = word char). תיקון: lookahead/lookbehind
- **Text-Heavy Threshold** — סף 2000 מילים חסם שרטוטים עם routing chart. שונה ל-700 מילים/עמוד
- **Text-Heavy V3** — keyword bypass (DRAWING NO, P.N., SCALE → skip check)
- **PO DPI** — 400 DPI × zoom ×3 = 135MP = 3.5 שעות. הופחת ל-200 DPI × zoom ×2 = 11MP = 30 שניות
- **Smart DPI** — שרטוטים ענקיים (>12K px) לא עוברים upscale ל-400 DPI
- **Stop Button** — `_stop_event` לא נבדק בלולאת המיילים. הוספת check בתחילת כל מייל
- **State Save** — באג: per-message save כתב dict ריק. תוקן + logging + fallback
- **Exception Logging** — outer try/except שינה מ-debug ל-error + full traceback

### חדש
- **Dashboard: Items per Mail** — סקציה חדשה עם ממוצע, חציון, התפלגות
- **Dashboard: Reset with Time** — שדה שעה:דקה באיפוס סטטיסטיקה
- **Smart P.N. Voting** — pdfplumber + Tesseract + Vision voting

## [3.0.0] - 2026-02-01

### חדש
- Automation Runner — ניטור אוטומטי של Shared Mailbox
- 5 GUI Panels — Automation, Extractor, Dashboard, Email, Send
- Parts List integration — PL parsing + association
- 3 customer models — Rafael, IAI, Generic
- Confidence system — FULL/HIGH/MEDIUM/LOW
- B2B variants — 3 versions filtered by confidence

## [2.0.0] - 2025-12-01

### חדש
- Multi-stage pipeline (9 stages)
- Azure OpenAI GPT-4o integration
- Microsoft Graph API (replacing EWS)
- OCR engine with Tesseract + pdfplumber
- Disambiguation engine (O↔0, B↔8)
