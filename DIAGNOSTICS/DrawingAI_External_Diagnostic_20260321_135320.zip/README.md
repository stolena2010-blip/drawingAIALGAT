# DrawingAI Pro

**Automated engineering drawing analysis powered by Azure OpenAI Vision API.**

## Overview

DrawingAI Pro automates the extraction of technical data from engineering drawings received via email. It processes PDF/image files through multi-stage AI analysis, classifies documents, extracts part numbers, materials, processes, and surface treatments, then generates structured Excel and B2B reports.

## Key Features

- **Multi-stage extraction**: basic info, processes, notes, geometric area, validation
- **Customer-specific logic** (IAI / RAFAEL variants)
- **File classification** (drawings vs documents)
- **B2B export** with confidence levels (LOW/MEDIUM/HIGH)
- **Automated email workflow**: receive → download → analyze → export → send
- **Multi-mailbox support** via Microsoft Graph API
- **Cost tracking** per Azure API stage
- **OCR** with Tesseract + advanced image preprocessing

## Architecture

```
customer_extractor_v3_dual.py    — Main orchestrator (scan_folder + extraction pipeline)
src/
├── core/constants.py            — Shared constants and configuration
├── services/
│   ├── ai/vision_api.py         — Azure OpenAI API calls with retry logic
│   ├── image/processing.py      — Image preprocessing, rotation, OCR
│   ├── extraction/
│   │   ├── filename_utils.py    — Part number extraction and OCR disambiguation
│   │   └── document_reader.py   — Email and document content parsing
│   ├── file/
│   │   ├── classifier.py        — AI-powered file type classification
│   │   └── file_utils.py        — Metadata, renaming, TO_SEND operations
│   ├── reporting/
│   │   ├── excel_export.py      — Excel summary and classification reports
│   │   ├── b2b_export.py        — B2B text file generation
│   │   └── pl_generator.py      — PL summary generation (Hebrew/English)
│   └── email/                   — Microsoft Graph API email integration
└── utils/logger.py              — Logging with rotation and GUI callback
```

## Quick Start

### Prerequisites

- Python 3.10+
- Tesseract OCR installed
- Azure OpenAI API access

### Installation

```bash
git clone <repo-url>
cd "AI DRAW"
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your Azure OpenAI credentials
```

### Running

```bash
python main.py              # CLI mode
python Run_GUI.bat          # GUI mode (Windows)
```

### Running Tests

```bash
python -m pytest tests/ -v
```

## Configuration

All configuration is via `.env` file. See `.env.example` for available options.

## Project Stats

- 64 automated tests
- 10 focused modules
- Multi-mailbox email automation
- 99.7% success rate in production (594 emails processed)
