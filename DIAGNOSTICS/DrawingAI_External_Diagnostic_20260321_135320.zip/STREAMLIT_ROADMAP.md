# Streamlit Migration Roadmap — DrawingAI Pro

> **Status: ✅ COMPLETE** — All 5 phases implemented (2026-03-10)

## מה ועל מה

מעבר GUI מ-**Tkinter / CustomTkinter** (דסקטופ) ל-**Streamlit** (Web).  
שני מסכים עיקריים: **לוח אוטומציה** + **Dashboard**, ולצדם **Email Panel** ו-**Send-Folder**.

### Implementation Summary

| Phase | Status | Files Created |
|-------|--------|--------------|
| Phase 0 — Setup | ✅ | `streamlit_app/app.py`, `.streamlit/config.toml`, scaffold |
| Phase 1 — Dashboard | ✅ | `backend/log_reader.py`, `pages/1_📊_Dashboard.py` |
| Phase 2 — Automation | ✅ | `backend/config_manager.py`, `backend/runner_bridge.py`, `pages/2_🚀_Automation.py` |
| Phase 3 — Email | ✅ | `backend/email_helpers.py`, `pages/3_📧_Email.py` |
| Phase 4 — Send Folder | ✅ | `pages/4_📤_SendFolder.py` |
| Phase 5 — Polish | ✅ | `components/shared_ui.py`, `Run_Web.bat`, `Dockerfile`, `docker-compose.yml` |

**Launch:** `Run_Web.bat` or `streamlit run streamlit_app/app.py`  
**Docker:** `docker compose up -d` → http://localhost:8501

---

## 1 · מצב נוכחי — סיכום רכיבים

| קובץ | שורות | תפקיד | Widgets עיקריים |
|-------|--------|--------|-----------------|
| `automation_panel_gui.py` | 1 454 | לוח בקרה + הגדרות + לוג | ~35 Entry, 18 Combobox, 22 Checkbox, 10 Buttons, Canvas animation |
| `dashboard_gui.py` | 1 605 | סטטיסטיקות + גרפים + ייצוא | כרטיסי מדדים, ASCII charts, טבלת מיילים, Human-verify dropdown |
| `email_panel_gui.py` | 485 | ניהול תיבות דואר | Listbox (folders), Entry, Text (email body) |
| `send_folder_mail_gui.py` | 716 | שליחת תקייה | Entry, Radiobutton, file browser |
| `customer_extractor_gui.py` | 1 304 | חילוץ ידני (legacy) | ProgressBar, stage checkboxes, results window |

**סך-הכל: ~5 564 שורות Tkinter → יעד: ~2 500–3 000 שורות Streamlit** (הפחתה ~50%)

---

## 2 · ארכיטקטורה — Before vs. After

### היום (Tkinter)
```
automation_main.py          ──► AutomationPanel (Tkinter mainloop, single-thread)
                                   ├─ AutomationRunner (threading.Thread)
                                   ├─ GraphAPIHelper
                                   └─ DashboardWindow (Toplevel)
```
- **מגבלה:** ריצה מקומית בלבד, threading מורכב, GUI freeze.

### אחרי (Streamlit)
```
streamlit_app.py            ──► 🌐 Browser
  ├─ pages/1_automation.py       ◄── st.session_state + AutomationRunner
  ├─ pages/2_dashboard.py        ◄── Plotly/Altair charts
  ├─ pages/3_email.py            ◄── Email management
  └─ pages/4_send_folder.py      ◄── Bulk send
  
  automation_runner.py           ◄── ללא שינוי — backend חשוף כ-API
```

**יתרונות:**
- גישה מרחוק מ-browser
- גרפיקה חזקה (Plotly / Altair במקום ASCII)
- RTL layout פשוט יותר (CSS)
- Deployment קל (Docker / Streamlit Cloud)

**חסרונות / אתגרים:**
- Streamlit = stateless rerun — חייב session_state מסודר
- Real-time log: דורש `st.empty()` + polling (אין WebSocket native)
- File browser: אין `filedialog.askdirectory()` — צריך `st.text_input` עם נתיבים או `st_folder_selector`
- Gollum animation: Canvas → CSS/Lottie

---

## 3 · מבנה הפרויקט — Streamlit App

```
streamlit_app/
├── app.py                    # Entry point: st.set_page_config, sidebar navigation
├── pages/
│   ├── 1_🚀_Automation.py    # Automation panel page
│   ├── 2_📊_Dashboard.py     # Statistics dashboard page
│   ├── 3_📧_Email.py         # Email management page
│   └── 4_📤_Send_Folder.py   # Batch send page
├── components/
│   ├── config_editor.py      # Settings form (shared between pages)
│   ├── log_viewer.py         # Live log display component
│   ├── metric_cards.py       # Dashboard summary cards
│   ├── charts.py             # Plotly chart builders
│   └── gollum.py             # Gollum animation (CSS/Lottie)
├── backend/
│   ├── runner_bridge.py      # Wraps AutomationRunner for Streamlit
│   ├── config_manager.py     # Read/write automation_config.json
│   └── log_reader.py         # JSONL reader + dedup + filter
├── assets/
│   ├── gollum.png
│   ├── style.css             # RTL + custom theme
│   └── lottie_ring.json      # Optional Gollum animation
└── requirements_streamlit.txt
```

---

## 4 · Phase Plan — שלבים

### Phase 0 — הכנה (1–2 ימים)

| משימה | פירוט |
|--------|--------|
| **0.1** התקנת Streamlit | `pip install streamlit plotly streamlit-autorefresh` |
| **0.2** הפרדת Backend מ-GUI | לוודא ש-`AutomationRunner`, `GraphAPIHelper`, config I/O עובדים ללא Tkinter imports |
| **0.3** Scaffolding | ליצור את מבנה `streamlit_app/` + `app.py` ריק עם sidebar |
| **0.4** RTL + Theme | CSS inject: `direction: rtl; text-align: right;` + `st.set_page_config(layout="wide")` |

**ריסק:** `AutomationRunner` כרגע מקבל reference ל-Panel לעדכון GUI — צריך להחליף ב-callback/queue.

---

### Phase 1 — Dashboard (3–4 ימים) ⭐ הכי קל להתחיל

**למה קודם?** Read-only display, אין תלות בריצה, הכי פשוט למפות.

| Tkinter Widget | Streamlit Equivalent |
|----------------|---------------------|
| Summary cards (LabelFrame + labels) | `st.metric()` × 6 in `st.columns(6)` |
| Filter radios (Today/Week/Month/All) | `st.radio(horizontal=True)` + `st.date_input()` for custom |
| ASCII bar charts | `st.plotly_chart()` / `st.bar_chart()` |
| Accuracy distribution bar (Canvas) | `st.plotly_chart(go.Bar(orientation='h'))` |
| Items histogram (Canvas bars) | `st.plotly_chart(go.Histogram())` |
| Customer accuracy table | `st.dataframe()` with column_config |
| Recent emails table | `st.data_editor()` with selectbox column for human_verified |
| Weights dialog (Toplevel) | `st.expander("⚙️ Accuracy Weights")` + `st.number_input()` |
| Excel export | `st.download_button()` + openpyxl in-memory |
| Reset stats dialog | `st.popover()` or `st.dialog()` (Streamlit 1.36+) |

**מבנה הדף:**
```python
# pages/2_📊_Dashboard.py
import streamlit as st
from backend.log_reader import load_logs, filter_by_date
from components.metric_cards import show_summary
from components.charts import accuracy_trend, daily_breakdown, items_histogram

st.title("📊 Dashboard — My Precious DrawingAI Pro")

# ── Filters ──
period = st.radio("תקופה", ["היום", "שבוע", "חודש", "הכל", "מותאם"], horizontal=True)
if period == "מותאם":
    col1, col2 = st.columns(2)
    date_from = col1.date_input("מתאריך")
    date_to = col2.date_input("עד תאריך")

df = load_logs()
df_filtered = filter_by_date(df, period)

# ── Summary Cards ──
show_summary(df_filtered)

# ── Charts ──
tab1, tab2, tab3 = st.tabs(["📈 דיוק", "💰 עלויות", "📧 מיילים"])
with tab1:
    accuracy_trend(df_filtered)
with tab2:
    daily_breakdown(df_filtered)
with tab3:
    st.data_editor(df_filtered[["timestamp","sender","cost_usd","status"]])
```

---

### Phase 2 — Automation Panel (5–7 ימים) ⭐ המורכב ביותר

| Section | Streamlit Approach |
|---------|-------------------|
| **Config fields** (~35 entries, 18 combos, 22 checks) | `st.sidebar` or `st.form()` — group into expanders |
| **Email + Folders** | `st.text_input()` × 5, `st.selectbox()` for folder |
| **Skip senders/categories** | `st.multiselect()` or `st.data_editor(["sender1","sender2"])` |
| **Stages + Models** | `st.columns(5)` × 2 rows, each: `st.checkbox()` + `st.selectbox()` |
| **Run Settings** | `st.number_input()` + `st.checkbox()` |
| **Advanced Settings** | `st.expander("⚙️ Advanced")` — sliders, combos, toggles |
| **Action Buttons** | `st.columns()` with `st.button()` — Save / Test / Run / Start / Stop |
| **Live Log** | `st.empty()` container + `streamlit-autorefresh` (2s) / `st.fragment` |
| **Status Bar** | `st.status()` or custom metric at top |
| **Gollum Animation** | `st_lottie` component or CSS keyframes |

**אתגרים טכניים:**

**A. State Management:**
```python
# session_state holds the running AutomationRunner
if "runner" not in st.session_state:
    st.session_state.runner = None
    st.session_state.is_running = False
    st.session_state.log_lines = []
```

**B. Long-Running Process (Start/Stop):**
Streamlit reruns the script on every interaction. To keep AutomationRunner alive:
```python
# Option 1: Background thread in session_state
if st.button("🚀 Start"):
    runner = AutomationRunner(config)
    st.session_state.runner = runner
    runner.start()  # threading.Thread

if st.button("⏹ Stop"):
    st.session_state.runner.stop()
```

**C. Live Log Display:**
```python
# Use st.fragment (Streamlit 1.37+) for partial reruns
@st.fragment(run_every=2)  # Auto-refresh every 2 seconds
def log_panel():
    log_file = Path("logs/drawingai_latest.log")
    lines = log_file.read_text().splitlines()[-100:]
    st.code("\n".join(lines), language="log")

log_panel()
```

**D. File/Folder Paths:**
```python
# No native folder browser — use text input with validation
folder = st.text_input("📁 Download folder", value=config.get("download_root", ""))
if folder and not Path(folder).exists():
    st.error("Folder does not exist")
```

**מבנה הדף:**
```python
# pages/1_🚀_Automation.py
import streamlit as st
from backend.config_manager import load_config, save_config
from backend.runner_bridge import get_or_create_runner

st.title("🚀 Automation — My Precious DrawingAI Pro")

config = load_config()

# ── Status Bar ──
col_status, col_counter, col_cost = st.columns([3, 1, 1])
col_status.markdown(f"**Status:** {'🟢 Running' if st.session_state.get('is_running') else '🔴 Stopped'}")

# ── Settings Form ──
with st.form("settings_form"):
    # Email
    st.subheader("📧 Email & Folders")
    config["shared_mailbox"] = st.text_input("Shared Mailbox", config.get("shared_mailbox",""))
    # ... more fields ...
    
    # Stages
    st.subheader("🔧 Stages & Models")
    cols = st.columns(5)
    for i in range(10):
        with cols[i % 5]:
            config[f"stage{i}_enabled"] = st.checkbox(f"Stage {i}", value=config.get(f"stage{i}_enabled", True))
            config[f"stage{i}_model"] = st.selectbox(f"Model", ["gpt-5.4","gpt-4o-vision","gpt-4o-mini","o4-mini"], key=f"model_{i}")
    
    submitted = st.form_submit_button("💾 Save")
    if submitted:
        save_config(config)
        st.success("Saved!")

# ── Action Buttons ──
col1, col2, col3, col4, col5 = st.columns(5)
with col1:
    if st.button("🔌 Test Connection"): ...
with col2:
    if st.button("▶️ Run Once"): ...
with col3:
    if st.button("🚀 Start"): ...
with col4:
    if st.button("⏹ Stop"): ...
with col5:
    if st.button("🔄 Reset"): ...

# ── Log ──
st.subheader("📜 Log")
log_panel()  # fragment with auto-refresh
```

---

### Phase 3 — Email Panel (2–3 ימים)

| Tkinter | Streamlit |
|---------|-----------|
| Folder Listbox | `st.dataframe()` with folder name + count |
| Manual email (Text widget) | `st.text_area()` for body |
| File attachments | `st.file_uploader(accept_multiple_files=True)` |
| Download from folder | `st.button()` + progress via `st.progress()` |

---

### Phase 4 — Send Folder (1–2 ימים)

| Tkinter | Streamlit |
|---------|-----------|
| Folder picker | `st.text_input()` + validation |
| Confidence radios | `st.radio(["LOW","MEDIUM","HIGH"])` |
| File count display | `st.metric("Files", count)` |
| Send button | `st.button()` with `st.spinner()` |

---

### Phase 5 — Polish & Deploy (2–3 ימים)

| משימה | פירוט |
|--------|--------|
| **5.1** RTL CSS | Inject full RTL stylesheet, Hebrew fonts |
| **5.2** Gollum theme | Dark theme via `.streamlit/config.toml` + Lottie animation |
| **5.3** Authentication | `streamlit-authenticator` or basic password gate |
| **5.4** Batch launchers | Update `Run_GUI.bat` → `streamlit run streamlit_app/app.py` |
| **5.5** Docker | `Dockerfile` + `docker-compose.yml` for server deploy |
| **5.6** E2E testing | Playwright or Selenium tests for critical flows |

---

## 5 · Widget Mapping — Full Reference

| Tkinter/CTk Widget | Count | Streamlit Replacement |
|--------------------|-------|-----------------------|
| `ttk.Entry` | ~35 | `st.text_input()` |
| `ttk.Combobox` | ~18 | `st.selectbox()` |
| `ttk.Checkbutton` | ~22 | `st.checkbox()` |
| `ttk.Radiobutton` | ~9 | `st.radio()` |
| `ttk.Button` / `CTkButton` | ~45 | `st.button()` |
| `ttk.LabelFrame` | ~25 | `st.expander()` / `st.container()` |
| `tk.Text` (log/body) | ~4 | `st.code()` / `st.text_area()` |
| `tk.Listbox` | ~4 | `st.multiselect()` / `st.dataframe()` |
| `tk.Canvas` (charts) | ~6 | `st.plotly_chart()` / `st.bar_chart()` |
| `CTkProgressBar` | 1 | `st.progress()` |
| `tk.Toplevel` (dialogs) | ~5 | `st.dialog()` / `st.popover()` |
| `tkinter.filedialog` | ~6 | `st.text_input()` + `Path.exists()` |
| `tkinter.messagebox` | ~10 | `st.toast()` / `st.error()` / `st.success()` |

---

## 6 · Dependencies — מה מוסיפים

```txt
# requirements_streamlit.txt (additive to existing requirements.txt)
streamlit>=1.37.0
plotly>=5.18.0
streamlit-autorefresh>=1.0.0
streamlit-lottie>=0.0.5        # Optional: Gollum animation
streamlit-authenticator>=0.3.0 # Optional: login gate
watchdog>=3.0.0                # Optional: file watcher for log
```

**מה מוסרים (אחרי מיגרציה מלאה):**
```txt
# ניתן להסיר
customtkinter>=5.2.0
# pyttsx3 — Gollum whisper TTS (if dropping)
```

---

## 7 · סיכונים ומיטיגציה

| סיכון | חומרה | מיטיגציה |
|--------|--------|----------|
| **Stateless reruns** — Streamlit reruns entire script on interaction | גבוה | `st.session_state` לכל state, `st.form()` למניעת reruns מיותרים |
| **Long-running runner** — AutomationRunner must survive reruns | גבוה | Store in `st.session_state`, thread-safe bridge, health heartbeat |
| **No native file browser** | בינוני | `st.text_input` with path validation + auto-complete, or `st_folder_selector` community widget |
| **Real-time log** — Streamlit polls, no push | בינוני | `st.fragment(run_every=2)` for partial rerun, or `streamlit-autorefresh` |
| **RTL layout** — Hebrew text alignment | נמוך | CSS injection: `st.markdown("<style>...</style>", unsafe_allow_html=True)` |
| **Concurrent users** — Each browser tab = separate session | נמוך | One runner shared via file lock / singleton pattern |
| **Excel export** — openpyxl writes to disk | נמוך | Write to `BytesIO` + `st.download_button(data=buffer)` |

---

## 8 · לוח זמנים — סיכום

| שלב | משך | מאמץ | תלות |
|------|------|------|------|
| Phase 0 — Setup | 1–2 days | ★☆☆ | — |
| Phase 1 — Dashboard | 3–4 days | ★★☆ | Phase 0 |
| Phase 2 — Automation Panel | 5–7 days | ★★★ | Phase 0 |
| Phase 3 — Email Panel | 2–3 days | ★★☆ | Phase 0 |
| Phase 4 — Send Folder | 1–2 days | ★☆☆ | Phase 0 |
| Phase 5 — Polish & Deploy | 2–3 days | ★★☆ | All |
| **סך-הכל** | **14–21 ימי עבודה** | | |

**סדר מומלץ:** Phase 0 → Phase 1 (Dashboard) → Phase 2 (Automation) → Phase 3+4 → Phase 5

> **הערה:** את ה-Tkinter GUI לא חובה למחוק — אפשר לשמור שני paths במקביל
> (bat file for desktop, `streamlit run` for web) עד שה-Streamlit מוכנה 100%.

---

## 9 · Quick Start — שלב ראשון

```bash
# Install
pip install streamlit plotly streamlit-autorefresh

# Create app skeleton
mkdir streamlit_app streamlit_app/pages streamlit_app/components streamlit_app/backend streamlit_app/assets

# Launch
streamlit run streamlit_app/app.py --server.port 8501
```

```python
# streamlit_app/app.py
import streamlit as st

st.set_page_config(
    page_title="DrawingAI Pro",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

# RTL support
st.markdown("""
<style>
    .stApp { direction: rtl; }
    .stMarkdown, .stText { text-align: right; }
    /* Keep code blocks LTR */
    pre, code { direction: ltr; text-align: left; }
</style>
""", unsafe_allow_html=True)

st.sidebar.title("🤖 DrawingAI Pro")
st.sidebar.markdown("---")
st.title("ברוכים הבאים ל-DrawingAI Pro")
st.info("בחר עמוד מהתפריט השמאלי")
```

---

*Generated: 2026-03-10 | AI DRAW Project*
